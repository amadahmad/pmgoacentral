
     function format_ldate(oObj) {
         if(oObj != null) {
            var aDate = oObj.split('-');
            var bDate = aDate[2].split(' ');
            year = aDate[0]; month = aDate[1]; day = bDate[0]; time = bDate[1];
            if(JS_DATE == 'dd-mm-yyyy') 
            return day + "-" + month + "-" + year + " " + time;
            else if(JS_DATE === 'dd/mm/yyyy') 
            return day + "/" + month + "/" + year + " " + time;
            else if(JS_DATE == 'dd.mm.yyyy') 
            return day + "." + month + "." + year + " " + time;
            else if(JS_DATE == 'mm/dd/yyyy') 
            return month + "/" + day + "/" + year + " " + time;
            else if(JS_DATE == 'mm-dd-yyyy') 
            return month + "-" + day + "-" + year + " " + time;
            else if(JS_DATE == 'mm.dd.yyyy') 
            return month + "." + day + "." + year + " " + time;
            else 
            return oObj;
         } else {
             return '';
         }
    }
    
    function format_sdate(oObj) {
         if(oObj != null) {
            var aDate = oObj.split('-');
            if(JS_DATE == 'dd-mm-yyyy') 
            return aDate[2] + "-" + aDate[1] + "-" + aDate[0];
            else if(JS_DATE === 'dd/mm/yyyy') 
            return aDate[2] + "/" + aDate[1] + "/" + aDate[0];
            else if(JS_DATE == 'dd.mm.yyyy') 
            return aDate[2] + "." + aDate[1] + "." + aDate[0];
            else if(JS_DATE == 'mm/dd/yyyy') 
            return aDate[1] + "/" + aDate[2] + "/" + aDate[0];
            else if(JS_DATE == 'mm-dd-yyyy') 
            return aDate[1] + "-" + aDate[2] + "-" + aDate[0];
            else if(JS_DATE == 'mm.dd.yyyy') 
            return aDate[1] + "." + aDate[2] + "." + aDate[0];
            else 
            return oObj;
         } else {
             return '';
         }
    }
         function currencyFormate(x) {
                if(x != null) {
                        var parts = x.toString().split(".");
                        return  parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",")+(parts[1] ? "." + parts[1] : ".00");
                } else {
                        return '0.00';
                }
        }                             